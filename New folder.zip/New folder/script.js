// بيانات المستخدمين (سيتم تخزينها في localStorage)
let users = JSON.parse(localStorage.getItem('users')) || [];

// بيانات الواجبات (سيتم تخزينها في localStorage)
let assignments = JSON.parse(localStorage.getItem('assignments')) || [];

// عناصر DOM
const loginSection = document.getElementById('login-section');
const signupSection = document.getElementById('signup-section');
const teacherSection = document.getElementById('teacher-section');
const studentSection = document.getElementById('student-section');
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const signupLink = document.getElementById('signup-link');
const loginLink = document.getElementById('login-link');
const assignmentForm = document.getElementById('assignment-form');
const assignmentsList = document.getElementById('assignments-list');
const questionForm = document.getElementById('question-form');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatMessages = document.getElementById('chat-messages');

// عرض قسم إنشاء الحساب
signupLink.addEventListener('click', function (e) {
    e.preventDefault();
    loginSection.classList.add('hidden');
    signupSection.classList.remove('hidden');
});

// العودة إلى تسجيل الدخول
loginLink.addEventListener('click', function (e) {
    e.preventDefault();
    signupSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
});

// إنشاء حساب جديد
signupForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;
    const role = document.getElementById('signup-role').value;

    if (username && password && role) {
        const userExists = users.some(u => u.username === username);
        if (userExists) {
            alert('اسم المستخدم موجود بالفعل!');
        } else {
            const newUser = { username, password, role };
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));
            alert('تم إنشاء الحساب بنجاح!');
            signupSection.classList.add('hidden');
            loginSection.classList.remove('hidden');
        }
    }
});

// تسجيل الدخول
loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        loginSection.classList.add('hidden');
        if (user.role === 'teacher') {
            teacherSection.classList.remove('hidden');
        } else {
            studentSection.classList.remove('hidden');
        }
    } else {
        alert('اسم المستخدم أو كلمة المرور غير صحيحة!');
    }
});

// نشر الواجب
assignmentForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('assignment-title').value;
    const description = document.getElementById('assignment-description').value;

    if (title && description) {
        const assignment = { title, description };
        assignments.push(assignment);
        localStorage.setItem('assignments', JSON.stringify(assignments));
        displayAssignments();
        assignmentForm.reset();
        showNotification('تم نشر واجب جديد!');
    }
});

// عرض الواجبات
function displayAssignments() {
    assignmentsList.innerHTML = '';
    assignments.forEach((assignment, index) => {
        const assignmentDiv = document.createElement('div');
        assignmentDiv.classList.add('assignment');
        assignmentDiv.innerHTML = `
            <h3>${assignment.title}</h3>
            <p>${assignment.description}</p>
        `;
        assignmentsList.appendChild(assignmentDiv);
    });
}

// إرسال سؤال
questionForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const question = document.getElementById('student-question').value;
    if (question) {
        alert('تم إرسال سؤالك بنجاح!');
        questionForm.reset();
    }
});

// إرسال رسالة دردشة
chatForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const message = chatInput.value;
    if (message) {
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);
        chatInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});

// إشعارات
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

// تقويم
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: [
            { title: 'تسليم الواجب 1', date: '2023-10-15' },
            { title: 'اختبار الرياضيات', date: '2023-10-20' }
        ]
    });
    calendar.render();
});